package com.voterapp

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.DocumentsContract
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var db: Db
    private val writer = Executors.newSingleThreadExecutor()
    private val reader = Executors.newFixedThreadPool(2)
    private val pdfs = ArrayList<Uri>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = Db(this)
        web = WebView(this)
        setContentView(web)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/pdf/", WebViewAssetLoader.PathHandler { path -> openPdf(path) })
            .build()

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val u = request?.url ?: return null
                return loader.shouldInterceptRequest(u)
            }
        }
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = false
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    /** ব্যাক: ওয়েব অংশ নিজে সামলাতে পারলে (কার্ড বন্ধ / সার্চে ফেরা) সামলায়, নইলে অ্যাপ থেকে বের হয় */
    override fun onBackPressed() {
        web.evaluateJavascript("(window.__back && window.__back()) ? 'yes' : 'no'") { r ->
            if (r == null || !r.contains("yes")) {
                finish()
            }
        }
    }

    private fun copyToClipboard(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("voter", text))
    }

    /** ডেটাবেস ফোল্ডার ফাইল-ম্যানেজারে খোলার চেষ্টা; না পারলে পাথ কপি করে জানায় */
    private fun openDataFolder() {
        val dir = db.dir()
        val base = Environment.getExternalStorageDirectory().absolutePath + "/"
        var opened = false
        if (dir.startsWith(base)) {
            val rel = dir.substring(base.length)
            val uri = Uri.parse("content://com.android.externalstorage.documents/document/primary%3A" + Uri.encode(rel))
            try {
                val i = Intent(Intent.ACTION_VIEW)
                i.setDataAndType(uri, "vnd.android.document/directory")
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
                opened = true
            } catch (e: Exception) {
                opened = false
            }
        }
        if (!opened) {
            copyToClipboard(dir)
            Toast.makeText(this, "ফোল্ডার খোলা যায়নি। পাথ কপি হয়েছে: " + dir, Toast.LENGTH_LONG).show()
        }
    }

    /** PDF ফাইলের বাইট ওয়েব অংশে পাঠায় (/pdf/<নম্বর>) */
    private fun openPdf(path: String): WebResourceResponse? {
        val i = path.trim('/').toIntOrNull() ?: return null
        val uri: Uri = synchronized(pdfs) { pdfs.getOrNull(i) } ?: return null
        return try {
            val st = contentResolver.openInputStream(uri)
            if (st == null) null else WebResourceResponse("application/pdf", null, st)
        } catch (e: Exception) {
            null
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun pickFolder() {
            runOnUiThread {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                startActivityForResult(i, 1)
            }
        }

        @JavascriptInterface
        fun copyText(text: String) {
            runOnUiThread {
                copyToClipboard(text)
                Toast.makeText(this@MainActivity, "কপি হয়েছে: " + text, Toast.LENGTH_SHORT).show()
            }
        }

        @JavascriptInterface
        fun openFolder() {
            runOnUiThread { openDataFolder() }
        }

        @JavascriptInterface
        fun keepAwake(on: Boolean) {
            runOnUiThread {
                if (on) {
                    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                }
            }
        }

        @JavascriptInterface
        fun rpc(id: Int, op: String, payload: String) {
            val ex = if (op == "query" || op == "dbsize" || op == "dbpath") reader else writer
            ex.execute {
                val out: String = try {
                    handle(op, JSONObject(payload)).toString()
                } catch (e: Throwable) {
                    JSONObject().put("error", e.toString()).toString()
                }
                reply(id, out)
            }
        }
    }

    private fun handle(op: String, p: JSONObject): JSONObject {
        return when (op) {
            "init" -> {
                db.init(p.getJSONArray("statements"))
                JSONObject().put("ok", true)
            }
            "insert" -> JSONObject().put("n", db.insert(p.getString("sql"), p.getJSONArray("rows")))
            "query" -> db.query(p.getString("sql"), p.optJSONArray("args") ?: JSONArray())
            "clear" -> {
                db.clear(p.getJSONArray("statements"))
                JSONObject().put("ok", true)
            }
            "dbsize" -> JSONObject().put("bytes", db.sizeBytes())
            "dbpath" -> JSONObject().put("dir", db.dir()).put("file", db.path())
            "exec" -> {
                db.exec(p.getString("sql"), p.optJSONArray("args") ?: JSONArray())
                JSONObject().put("ok", true)
            }
            else -> throw IllegalArgumentException("unknown op " + op)
        }
    }

    private fun reply(id: Int, json: String) {
        val js = "window.__cb(" + id + "," + JSONObject.quote(json) + ")"
        runOnUiThread { web.evaluateJavascript(js, null) }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 1 || resultCode != RESULT_OK) return
        val tree: Uri = data?.data ?: return
        try {
            contentResolver.takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) {
            // স্থায়ী অনুমতি না পেলেও এই সেশনে কাজ চলবে
        }
        reader.execute {
            val found = ArrayList<Uri>()
            val list = JSONArray()
            walk(tree, DocumentsContract.getTreeDocumentId(tree), "", found, list)
            synchronized(pdfs) {
                pdfs.clear()
                pdfs.addAll(found)
            }
            val payload = JSONObject().put("files", list).toString()
            val js = "window.__folder(" + JSONObject.quote(payload) + ")"
            runOnUiThread { web.evaluateJavascript(js, null) }
        }
    }

    /** ফোল্ডার ও সব সাব-ফোল্ডার ঘুরে PDF খোঁজে */
    private fun walk(tree: Uri, docId: String, rel: String, out: ArrayList<Uri>, list: JSONArray) {
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val proj = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE
        )
        val c = contentResolver.query(children, proj, null, null, null) ?: return
        val dirs = ArrayList<Pair<String, String>>()
        try {
            while (c.moveToNext()) {
                val id = c.getString(0)
                val name = c.getString(1) ?: ""
                val mime = c.getString(2) ?: ""
                if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                    dirs.add(Pair(id, name))
                } else if (name.endsWith(".pdf", ignoreCase = true)) {
                    out.add(DocumentsContract.buildDocumentUriUsingTree(tree, id))
                    list.put(
                        JSONObject()
                            .put("i", out.size - 1)
                            .put("name", name)
                            .put("rel", rel)
                            .put("size", c.getLong(3))
                    )
                }
            }
        } finally {
            c.close()
        }
        for (d in dirs) {
            walk(tree, d.first, rel + "/" + d.second, out, list)
        }
    }
}
