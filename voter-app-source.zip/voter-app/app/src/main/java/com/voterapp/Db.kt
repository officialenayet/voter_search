package com.voterapp

import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** ফোনের স্টোরেজে SQLite ডেটাবেস। সব SQL ওয়েব অংশ (app.js) থেকে আসে, এখানে শুধু চালানো হয়। */
class Db(private val ctx: Context) {
    private var db: SQLiteDatabase? = null

    private fun file(): File = ctx.getDatabasePath("voters.db")

    @Synchronized
    private fun open(): SQLiteDatabase {
        var d = db
        if (d == null || !d.isOpen) {
            file().parentFile?.mkdirs()
            d = SQLiteDatabase.openOrCreateDatabase(file(), null)
            d.enableWriteAheadLogging()
            db = d
        }
        return d!!
    }

    fun init(statements: JSONArray) {
        val d = open()
        for (i in 0 until statements.length()) {
            d.execSQL(statements.getString(i))
        }
    }

    fun insert(sql: String, rows: JSONArray): Int {
        val d = open()
        d.beginTransaction()
        try {
            val st = d.compileStatement(sql)
            for (i in 0 until rows.length()) {
                val r = rows.getJSONArray(i)
                st.clearBindings()
                for (j in 0 until r.length()) {
                    val v: Any = r.get(j)
                    if (v == JSONObject.NULL) {
                        st.bindNull(j + 1)
                    } else if (v is Int) {
                        st.bindLong(j + 1, v.toLong())
                    } else if (v is Long) {
                        st.bindLong(j + 1, v)
                    } else if (v is Double) {
                        st.bindDouble(j + 1, v)
                    } else {
                        st.bindString(j + 1, v.toString())
                    }
                }
                st.executeInsert()
            }
            st.close()
            d.setTransactionSuccessful()
        } finally {
            d.endTransaction()
        }
        return rows.length()
    }

    fun query(sql: String, args: JSONArray): JSONObject {
        val d = open()
        val a = Array(args.length()) { i -> args.get(i).toString() }
        val c: Cursor = d.rawQuery(sql, a)
        val cols = JSONArray()
        val rows = JSONArray()
        try {
            for (i in 0 until c.columnCount) {
                cols.put(c.getColumnName(i))
            }
            while (c.moveToNext()) {
                val row = JSONArray()
                for (i in 0 until c.columnCount) {
                    when (c.getType(i)) {
                        Cursor.FIELD_TYPE_NULL -> row.put(JSONObject.NULL)
                        Cursor.FIELD_TYPE_INTEGER -> row.put(c.getLong(i))
                        Cursor.FIELD_TYPE_FLOAT -> row.put(c.getDouble(i))
                        else -> row.put(c.getString(i))
                    }
                }
                rows.put(row)
            }
        } finally {
            c.close()
        }
        return JSONObject().put("cols", cols).put("rows", rows)
    }

    /** সব ডেটা মুছে ডেটাবেস ফাইলই ডিলিট করে (স্টোরেজ সাথে সাথে খালি হয়), তারপর খালি টেবিল বানায়। */
    @Synchronized
    fun clear(statements: JSONArray) {
        db?.close()
        db = null
        ctx.deleteDatabase("voters.db")
        init(statements)
    }

    fun sizeBytes(): Long {
        val f = file()
        var s = 0L
        for (x in listOf(f, File(f.path + "-wal"), File(f.path + "-shm"))) {
            if (x.exists()) s += x.length()
        }
        return s
    }
}
