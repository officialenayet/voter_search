'use strict';
const $ = id => document.getElementById(id);
const BD = '০১২৩৪৫৬৭৮৯', bn = n => Number(n).toLocaleString('bn-BD');
const NATIVE = typeof window.Android !== 'undefined';

// ---------- অ্যান্ড্রয়েড ব্রিজ ----------
let cbId = 0; const cbs = {};
window.__cb = (id, json) => { const c = cbs[id]; delete cbs[id]; if (c) c(JSON.parse(json)); };
function rpc(op, payload) {
  return new Promise((ok, no) => {
    const id = ++cbId;
    cbs[id] = r => (r && r.error) ? no(new Error(r.error)) : ok(r);
    window.Android.rpc(id, op, JSON.stringify(payload || {}));
  });
}
async function q(sql, args) {           // সারি-অবজেক্টের তালিকা ফেরত দেয়
  const r = await rpc('query', { sql, args: args || [] });
  return r.rows.map(row => { const o = {}; r.cols.forEach((c, i) => o[c] = row[i]); return o; });
}

// ---------- বানান সহজ করা (সার্চের জন্য) ----------
function nz(s) {
  s = String(s || '').normalize('NFC');
  let o = '';
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (c >= '০' && c <= '৯') o += BD.indexOf(c);
    else if ('\u200c\u200d\u0981'.includes(c)) continue;
    else if (c === 'ী') o += 'ি'; else if (c === 'ূ') o += 'ু'; else if (c === 'ণ') o += 'ন';
    else if (c === 'শ' || c === 'ষ') o += 'স'; else if (c === 'ৎ') o += 'ত'; else if (c === '\u09DF') o += 'য';
    else if (c === '\u09BC' && s[i - 1] === 'য') continue;
    else o += c.toLowerCase();
  }
  return o;
}

// ---------- ডেটাবেস (দুই টেবিল: pdfs = প্রতি PDF-এর তথ্য, voters = ভোটার; ডেটাবেস ছোট থাকে) ----------
const SCHEMA = [
  'CREATE TABLE IF NOT EXISTS pdfs(fid INTEGER PRIMARY KEY,file TEXT UNIQUE,va TEXT,ward TEXT,union_name TEXT,upazila TEXT,district TEXT,gender TEXT,va_n TEXT,un_n TEXT,ward_n TEXT)',
  'CREATE TABLE IF NOT EXISTS voters(id INTEGER PRIMARY KEY,vno TEXT UNIQUE,serial TEXT,name TEXT,father TEXT,mother TEXT,job TEXT,dob TEXT,addr TEXT,name_n TEXT,father_n TEXT,mother_n TEXT,addr_n TEXT,dob_d INTEGER,dob_m INTEGER,dob_y INTEGER,fid INTEGER)',
  'CREATE INDEX IF NOT EXISTS i_fid ON voters(fid)',
];
const PDF_SQL = 'INSERT OR REPLACE INTO pdfs(file,va,ward,union_name,upazila,district,gender,va_n,un_n,ward_n) VALUES(?,?,?,?,?,?,?,?,?,?)';
const VOTER_SQL = 'INSERT OR REPLACE INTO voters(vno,serial,name,father,mother,job,dob,addr,name_n,father_n,mother_n,addr_n,dob_d,dob_m,dob_y,fid) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)';
const A = s => nz(s);                          // ইংরেজি অঙ্কে (সংখ্যা ছোট জায়গা নেয়)
const BDG = s => String(s == null ? '' : s).replace(/[0-9]/g, c => BD[c]);   // দেখানোর সময় আবার বাংলা অঙ্ক
function pdfRow(m) { return [m.file, m.va, m.ward, m.union, m.upazila, m.district, m.gender, nz(m.va), nz(m.union), nz(m.ward)]; }
function toRow(r, fid) {
  const d = nz(r.dob).match(/(\d+)\/(\d+)\/(\d+)/);
  return [r.no ? A(r.no) : null, A(r.serial), r.name, r.father, r.mother, r.job, A(r.dob), r.addr, nz(r.name), nz(r.father), nz(r.mother), nz(r.addr),
    d ? +d[1] : null, d ? +d[2] : null, d ? +d[3] : null, fid];
}

// ---------- PDF পড়া ----------
pdfjsLib.GlobalWorkerOptions.workerSrc = 'pdf.worker.min.js';
async function parsePdf(url, fileName) {
  const buf = await (await fetch(url)).arrayBuffer();
  const doc = await pdfjsLib.getDocument({ data: new Uint8Array(buf), isEvalSupported: false, disableFontFace: true, verbosity: 0 }).promise;
  const recs = [], head = [];
  const m = { file: fileName.replace(/\.pdf$/i, ''), va: '', ward: '', union: '', upazila: '', district: '', gender: '' };
  for (let p = 1; p <= doc.numPages; p++) {
    const pg = await doc.getPage(p), tc = await pg.getTextContent(), d = pageData(tc.items); pg.cleanup();
    if (p <= 3) head.push(...d.lines.slice(0, 16));
    if (!m.va) d.lines.forEach(l => {
      const v = l.match(/ভোটার এলাকার নাম:\s*(.+?)\s*$/), c = l.match(/ভোটার এলাকার কোড:\s*([০-৯]+)/);
      if (v) m.va = v[1].trim() + (c ? ' (' + c[1] + ')' : '');
    });
    if (!m.upazila) d.lines.forEach(l => {
      const a = l.match(/জেলা:\s*(.+?)\s*উপজেলা:\s*(.+?)\s*ইউনিয়ন:\s*(.+?)\s*ডাকঘর:/);
      if (a && !m.upazila) { m.district = a[1].trim(); m.upazila = a[2].trim(); m.union = a[3].trim(); }
    });
    recs.push(...d.recs);
    if (p % 3 === 0) await new Promise(r => setTimeout(r));
  }
  try { await doc.destroy(); } catch (e) {}
  const txt = head.join('\n');
  const w = txt.match(/ওয়ার্ড নম্বর\s*\(ইউনিয়ন পরিষদের জন্য\)\s*:?\s*([০-৯]+)/); m.ward = w ? w[1] : '';
  const g = txt.match(/ভোটার তালিকা\s*-\s*\((পুরুষ|মহিলা)\)/);
  m.gender = g ? (g[1] === 'মহিলা' ? 'নারী' : 'পুরুষ') : (/female/i.test(fileName) ? 'নারী' : (/male/i.test(fileName) ? 'পুরুষ' : ''));
  return { m, recs };
}

// ---------- ট্যাব ----------
function tab(t) {
  ['import', 'search', 'stats'].forEach(x => { $('v-' + x).classList.toggle('hide', x !== t); $('t-' + x).classList.toggle('on', x === t); });
  if (t === 'stats') stats(); if (t === 'search') search(true);
}
$('t-import').onclick = () => tab('import'); $('t-search').onclick = () => tab('search'); $('t-stats').onclick = () => tab('stats');

// ---------- সংরক্ষিত ডেটার তথ্য ----------
async function refreshInfo() {
  const a = { c: (await q('SELECT COUNT(*) c FROM voters'))[0].c, f: (await q('SELECT COUNT(*) f FROM pdfs'))[0].f };
  const sz = (await rpc('dbsize')).bytes;
  $('info').textContent = bn(a.c) + ' জন ভোটার, ' + bn(a.f) + 'টি PDF';
  $('dbinfo').textContent = 'ডেটাবেসে ' + bn(a.c) + ' জন ভোটার, ' + bn(a.f) + 'টি PDF থেকে। ফোনের স্টোরেজে জায়গা নিচ্ছে প্রায় ' + bn(Math.round(sz / 1048576)) + ' MB।';
  return a;
}

// ---------- ইমপোর্ট ----------
let FILES = [], running = false, stopFlag = false;
$('pick').onclick = () => { if (!NATIVE) { $('found').textContent = 'এটা শুধু অ্যান্ড্রয়েড অ্যাপে চলে।'; return; } $('found').textContent = 'ফোল্ডার খোঁজা হচ্ছে…'; window.Android.pickFolder(); };
window.__folder = async json => {
  const j = JSON.parse(json); FILES = j.files || [];
  const have = new Set((await q('SELECT file FROM pdfs')).map(x => x.file));
  FILES.forEach(f => f.done = have.has(f.name.replace(/\.pdf$/i, '')));
  const nw = FILES.filter(f => !f.done).length;
  $('found').textContent = bn(FILES.length) + 'টি PDF পাওয়া গেছে। আগেই ইমপোর্ট করা: ' + bn(FILES.length - nw) + 'টি। নতুন: ' + bn(nw) + 'টি।';
  $('runCard').style.display = FILES.length ? '' : 'none'; $('prog').textContent = ''; $('errs').textContent = ''; $('barI').style.width = '0';
};
const fmt = s => { s = Math.round(s); const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60); return (h ? bn(h) + ' ঘণ্টা ' : '') + bn(m) + ' মিনিট'; };
$('stop').onclick = () => { stopFlag = true; $('stop').disabled = true; $('cur').textContent = 'থামানো হচ্ছে…'; };
$('start').onclick = async () => {
  if (running) return; const todo = FILES.filter(f => !f.done); if (!todo.length) { $('prog').textContent = 'নতুন কোনো PDF নেই।'; return; }
  running = true; stopFlag = false; $('start').disabled = true; $('stop').disabled = false; $('pick').disabled = true; $('clear').disabled = true;
  window.Android.keepAwake(true);
  const t0 = Date.now(); let n = 0, recTotal = 0; const errs = [];
  for (let i = 0; i < todo.length && !stopFlag; i++) {
    const f = todo[i]; $('cur').textContent = f.name;
    try {
      const { m, recs } = await parsePdf('/pdf/' + f.i, f.name);
      if (!recs.length) throw new Error('কোনো ভোটার পাওয়া যায়নি');
      await rpc('insert', { sql: PDF_SQL, rows: [pdfRow(m)] });
      const fid = (await q('SELECT fid FROM pdfs WHERE file=?', [m.file]))[0].fid;
      const rows = recs.map(r => toRow(r, fid));
      for (let k = 0; k < rows.length; k += 2000) await rpc('insert', { sql: VOTER_SQL, rows: rows.slice(k, k + 2000) });
      recTotal += recs.length; f.done = true;
    } catch (e) { errs.push(f.name + ': ' + e.message); }
    n++;
    const sec = (Date.now() - t0) / 1000, left = (todo.length - n) * sec / n;
    $('barI').style.width = (n / todo.length * 100) + '%';
    $('prog').textContent = bn(n) + '/' + bn(todo.length) + ' PDF, ' + bn(recTotal) + ' জন যোগ হয়েছে। বাকি সময় আনুমানিক ' + fmt(left);
    $('errs').textContent = errs.length ? bn(errs.length) + 'টি PDF-এ সমস্যা: ' + errs.slice(0, 5).join(' | ') : '';
  }
  window.Android.keepAwake(false); running = false;
  $('cur').textContent = stopFlag ? 'থামানো হয়েছে। আবার ফোল্ডার বেছে শুরু করলে বাকিগুলো থেকে চলবে।' : 'সম্পন্ন ✓';
  $('start').disabled = false; $('stop').disabled = true; $('pick').disabled = false; $('clear').disabled = false;
  await refreshInfo(); LOADED_STATS = false;
};

// ---------- ডেটা মুছুন (দুইবার নিশ্চিত) ----------
let clearArm = 0;
$('clear').onclick = async () => {
  const b = $('clear');
  if (!clearArm) {
    clearArm = setTimeout(() => { clearArm = 0; b.textContent = '🗑 ডেটা মুছুন'; $('clearMsg').textContent = ''; }, 5000);
    b.textContent = '⚠ নিশ্চিত? আবার চাপুন'; $('clearMsg').textContent = 'আবার চাপলে সব ইমপোর্ট করা ডেটা মুছে ফোনের জায়গা খালি হবে। ৫ সেকেন্ডের মধ্যে চাপুন।'; return;
  }
  clearTimeout(clearArm); clearArm = 0; b.textContent = '🗑 ডেটা মুছুন';
  await rpc('clear', { statements: SCHEMA });
  FILES.forEach(f => f.done = false); $('clearMsg').textContent = 'সব ডেটা মুছে গেছে, স্টোরেজ খালি হয়েছে ✓';
  $('list').innerHTML = ''; $('count').textContent = ''; await refreshInfo(); LOADED_STATS = false;
};

// ---------- সার্চ ----------
const F = { job: '' };
function dobSql(s) {
  s = nz(s).replace(/[-–—.\s]+/g, '/'); const p = s.split('/').filter(Boolean);
  if (!p.length || !p.every(x => /^\d+$/.test(x))) return null; const n = p.map(Number);
  if (p.length >= 3) return p[2].length >= 4 ? ['dob_d=? AND dob_m=? AND dob_y=?', [n[0], n[1], n[2]]] : ['dob_d=? AND dob_m=? AND CAST(dob_y AS TEXT) LIKE ?', [n[0], n[1], p[2] + '%']];
  if (p.length === 2) return p[1].length >= 3 ? ['dob_m=? AND CAST(dob_y AS TEXT) LIKE ?', [n[0], p[1] + '%']] : ['dob_d=? AND dob_m=?', [n[0], n[1]]];
  return p[0].length >= 3 ? ['CAST(dob_y AS TEXT) LIKE ?', [p[0] + '%']] : ['dob_d=?', [n[0]]];
}
function buildWhere() {
  const w = [], a = [], steps = [], pw = [], pa = [];
  const like = (col, val, lab) => {
    const t = nz(val).split(/\s+/).filter(Boolean); if (!t.length) return;
    t.forEach(x => { w.push(col + " LIKE ? ESCAPE '\\'"); a.push('%' + x.replace(/[\\%_]/g, '\\$&') + '%'); }); steps.push(lab);
  };
  const plike = (col, val, lab) => {
    const t = nz(val).split(/\s+/).filter(Boolean); if (!t.length) return;
    t.forEach(x => { pw.push(col + " LIKE ? ESCAPE '\\'"); pa.push('%' + x.replace(/[\\%_]/g, '\\$&') + '%'); }); steps.push(lab);
  };
  like('v.name_n', $('f-name').value, 'নাম'); like('v.father_n', $('f-father').value, 'বাবা'); like('v.mother_n', $('f-mother').value, 'মা');
  const d = dobSql($('f-dob').value); if (d) { w.push('(' + d[0].replace(/dob_/g, 'v.dob_') + ')'); a.push(...d[1]); steps.push('জন্ম তারিখ'); }
  like('v.addr_n', $('f-addr').value, 'ঠিকানা');
  plike('un_n', $('f-union').value, 'ইউনিয়ন'); plike('va_n', $('f-va').value, 'ভোটার এলাকা');
  const wd = nz($('f-ward').value).trim(); if (wd) { pw.push('ward_n=?'); pa.push(wd); steps.push('ওয়ার্ড'); }
  const g = $('f-gender').value; if (g) { pw.push('gender=?'); pa.push(g); steps.push(g); }
  if (pw.length) { w.push('v.fid IN (SELECT fid FROM pdfs WHERE ' + pw.join(' AND ') + ')'); a.push(...pa); }
  if (F.job) { w.push('v.job=?'); a.push(F.job); steps.push('পেশা'); }
  return { sql: w.length ? ' WHERE ' + w.join(' AND ') : '', args: a, steps };
}
function chips() {
  const c = $('chips'); c.innerHTML = '';
  if (F.job) { const s = document.createElement('span'); s.className = 'chip'; s.textContent = 'পেশা: ' + F.job + ' ✕'; s.onclick = () => { F.job = ''; search(true); }; c.appendChild(s); }
}
function age(y, m, d) { if (!y) return ''; const n = new Date(); let a = n.getFullYear() - y; if (n.getMonth() + 1 < m || (n.getMonth() + 1 === m && n.getDate() < d)) a--; return a; }
let seq = 0, off = 0, curW = null, timer = null;
const SHOW = 'v.serial,v.vno AS voter_no,v.name,v.father,v.mother,v.job,v.dob,v.addr,v.dob_y,v.dob_m,v.dob_d,p.va AS voter_area,p.ward,p.union_name,p.upazila,p.district,p.gender,p.file';
const FROM = ' FROM voters v JOIN pdfs p ON p.fid=v.fid';
async function search(reset) {
  const my = ++seq; if (reset) { off = 0; $('list').innerHTML = ''; }
  const w = curW = buildWhere(); chips();
  $('steps').textContent = w.steps.length ? 'ফিল্টার: ' + w.steps.join(' + ') : 'ফিল্টার দিন (না দিলে প্রথম ৫০ জন দেখাবে)';
  let rows;
  try { rows = await q('SELECT ' + SHOW + FROM + w.sql + ' LIMIT 50 OFFSET ' + (off | 0), w.args); } catch (e) { $('count').textContent = 'সমস্যা: ' + e.message; return; }
  if (my !== seq) return;
  const L = $('list');
  rows.forEach(r => {
    const e = document.createElement('div'); e.className = 'v';
    const a = age(r.dob_y, r.dob_m, r.dob_d);
    const esc = s => String(s == null ? '' : s).replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
    e.innerHTML = '<b>' + esc(r.name) + '</b> <span class="t">' + esc(r.gender) + (a !== '' ? ', ' + bn(a) + ' বছর' : '') + '</span>' +
      '<div>পিতা: ' + esc(r.father) + '</div><div>মাতা: ' + esc(r.mother) + '</div>' +
      '<div>জন্ম: ' + esc(BDG(r.dob)) + ' | পেশা: ' + esc(r.job) + '</div><div>ঠিকানা: ' + esc(r.addr) + '</div>' +
      '<div class="l">ভোটার এলাকা: ' + esc(r.voter_area) + ' | ইউনিয়ন: ' + esc(r.union_name) + ' | ওয়ার্ড: ' + esc(r.ward) + '</div>' +
      '<div class="l">ক্রমিক: ' + esc(BDG(r.serial)) + ' | ভোটার নং: ' + esc(BDG(r.voter_no)) + '</div><div class="l">সোর্স: ' + esc(r.file) + '</div>';
    L.appendChild(e);
  });
  off += rows.length; $('more').classList.toggle('hide', rows.length < 50);
  if (reset) {
    $('count').textContent = 'গোনা হচ্ছে…';
    const c = (await q('SELECT COUNT(*) c FROM voters v' + w.sql, w.args))[0].c;
    if (my === seq) $('count').textContent = 'মোট ' + bn(c) + ' জন';
  }
}
['f-name', 'f-father', 'f-mother', 'f-dob', 'f-addr', 'f-union', 'f-va', 'f-ward'].forEach(id => $(id).oninput = () => { clearTimeout(timer); timer = setTimeout(() => search(true), 700); });
$('f-gender').onchange = () => search(true);
$('go').onclick = () => { clearTimeout(timer); search(true); };
$('more').onclick = () => search(false);
$('reset').onclick = () => { ['f-name', 'f-father', 'f-mother', 'f-dob', 'f-addr', 'f-union', 'f-va', 'f-ward'].forEach(id => $(id).value = ''); $('f-gender').value = ''; F.job = ''; search(true); };

// ---------- পরিসংখ্যান ----------
let statsMode = 'all', LOADED_STATS = false;
$('s-all').onclick = () => { statsMode = 'all'; $('s-all').classList.add('p'); $('s-cur').classList.remove('p'); stats(); };
$('s-cur').onclick = () => { statsMode = 'cur'; $('s-cur').classList.add('p'); $('s-all').classList.remove('p'); stats(); };
async function stats() {
  const w = statsMode === 'cur' ? buildWhere() : { sql: '', args: [] };
  const g = await q('SELECT p.gender gender, COUNT(*) c' + FROM + w.sql + ' GROUP BY p.gender', w.args);
  const cnt = k => (g.find(x => x.gender === k) || { c: 0 }).c, tot = g.reduce((a, x) => a + x.c, 0), pc = c => tot ? ' (' + bn((c / tot * 100).toFixed(1)) + '%)' : '';
  $('s-gender').innerHTML = '<div class="g">মোট<b>' + bn(tot) + '</b></div><div class="g">পুরুষ<b>' + bn(cnt('পুরুষ')) + '</b><span class="st">' + pc(cnt('পুরুষ')) + '</span></div><div class="g">নারী<b>' + bn(cnt('নারী')) + '</b><span class="st">' + pc(cnt('নারী')) + '</span></div>';
  const jobs = await q('SELECT v.job job, COUNT(*) c FROM voters v' + w.sql + ' GROUP BY v.job ORDER BY c DESC LIMIT 300', w.args);
  const mx = jobs.length ? jobs[0].c : 1, J = $('s-jobs'); J.innerHTML = '';
  jobs.forEach(j => {
    const e = document.createElement('div'); e.className = 'jr';
    const name = j.job || '(পেশা লেখা নেই)';
    e.innerHTML = '<div class="n"><span></span><b>' + bn(j.c) + (tot ? ' · ' + bn((j.c / tot * 100).toFixed(1)) + '%' : '') + '</b></div><div class="jb"><i style="width:' + (j.c / mx * 100) + '%"></i></div>';
    e.querySelector('span').textContent = name;
    e.onclick = () => { F.job = j.job || ''; if (F.job) { tab('search'); } };
    J.appendChild(e);
  });
}

// ---------- শুরু ----------
(async () => {
  if (!NATIVE) { $('info').textContent = 'এটা শুধু অ্যান্ড্রয়েড অ্যাপে চলে'; return; }
  await rpc('init', { statements: SCHEMA }); await refreshInfo();
})();
