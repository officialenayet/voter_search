'use strict';
const $ = id => document.getElementById(id);
const BD = '০১২৩৪৫৬৭৮৯', bn = n => Number(n).toLocaleString('bn-BD');
const NATIVE = typeof window.Android !== 'undefined';

// ---------- অ্যান্ড্রয়েড ব্রিজ ----------
let cbId = 0; const cbs = {};
window.__cb = (id, json) => { const c = cbs[id]; delete cbs[id]; if (c) c(JSON.parse(json)); };
function rpc(op, payload) {
  return new Promise((ok, no) => {
    const id = ++cbId;
    cbs[id] = r => (r && r.error) ? no(new Error(r.error)) : ok(r);
    window.Android.rpc(id, op, JSON.stringify(payload || {}));
  });
}
async function q(sql, args) {           // সারি-অবজেক্টের তালিকা ফেরত দেয়
  const r = await rpc('query', { sql, args: args || [] });
  return r.rows.map(row => { const o = {}; r.cols.forEach((c, i) => o[c] = row[i]); return o; });
}

// ---------- বানান সহজ করা (সার্চের জন্য) ----------
function nz(s) {
  s = String(s || '').normalize('NFC');
  let o = '';
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (c >= '০' && c <= '৯') o += BD.indexOf(c);
    else if ('\u200c\u200d\u0981'.includes(c)) continue;
    else if (c === 'ী') o += 'ি'; else if (c === 'ূ') o += 'ু'; else if (c === 'ণ') o += 'ন';
    else if (c === 'শ' || c === 'ষ') o += 'স'; else if (c === 'ৎ') o += 'ত'; else if (c === '\u09DF') o += 'য';
    else if (c === '\u09BC' && s[i - 1] === 'য') continue;
    else o += c.toLowerCase();
  }
  return o;
}

// ---------- নিজে যোগ করা যুক্তাক্ষর (অ্যাপের ভেতর থেকে) ----------
let CUSTOM = {};
try { CUSTOM = JSON.parse(localStorage.getItem('gmap') || '{}'); } catch (e) { CUSTOM = {}; }
Object.keys(CUSTOM).forEach(k => { M[k] = CUSTOM[k]; });

// ---------- ডেটাবেস (দুই টেবিল: pdfs = প্রতি PDF-এর তথ্য, voters = ভোটার; ডেটাবেস ছোট থাকে) ----------
const SCHEMA = [
  'CREATE TABLE IF NOT EXISTS pdfs(fid INTEGER PRIMARY KEY,file TEXT UNIQUE,va TEXT,ward TEXT,union_name TEXT,upazila TEXT,district TEXT,gender TEXT,va_n TEXT,un_n TEXT,ward_n TEXT)',
  'CREATE TABLE IF NOT EXISTS voters(id INTEGER PRIMARY KEY,vno TEXT UNIQUE,serial TEXT,name TEXT,father TEXT,mother TEXT,job TEXT,dob TEXT,addr TEXT,name_n TEXT,father_n TEXT,mother_n TEXT,addr_n TEXT,dob_d INTEGER,dob_m INTEGER,dob_y INTEGER,fid INTEGER)',
  'CREATE INDEX IF NOT EXISTS i_fid ON voters(fid)',
];
const PDF_SQL = 'INSERT OR REPLACE INTO pdfs(file,va,ward,union_name,upazila,district,gender,va_n,un_n,ward_n) VALUES(?,?,?,?,?,?,?,?,?,?)';
const VOTER_SQL = 'INSERT OR REPLACE INTO voters(vno,serial,name,father,mother,job,dob,addr,name_n,father_n,mother_n,addr_n,dob_d,dob_m,dob_y,fid) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)';
const A = s => nz(s);                          // ইংরেজি অঙ্কে (সংখ্যা ছোট জায়গা নেয়)
const BDG = s => String(s == null ? '' : s).replace(/[0-9]/g, c => BD[c]);   // দেখানোর সময় আবার বাংলা অঙ্ক
function pdfRow(m) { return [m.file, m.va, m.ward, m.union, m.upazila, m.district, m.gender, nz(m.va), nz(m.union), nz(m.ward)]; }
function toRow(r, fid) {
  const d = nz(r.dob).match(/(\d+)\/(\d+)\/(\d+)/);
  return [r.no ? A(r.no) : null, A(r.serial), r.name, r.father, r.mother, r.job, A(r.dob), r.addr, nz(r.name), nz(r.father), nz(r.mother), nz(r.addr),
    d ? +d[1] : null, d ? +d[2] : null, d ? +d[3] : null, fid];
}

// ---------- PDF পড়া ----------
pdfjsLib.GlobalWorkerOptions.workerSrc = 'pdf.worker.min.js';
async function parsePdf(url, fileName) {
  const buf = await (await fetch(url)).arrayBuffer();
  const doc = await pdfjsLib.getDocument({ data: new Uint8Array(buf), isEvalSupported: false, disableFontFace: true, verbosity: 0 }).promise;
  const recs = [], head = [];
  const m = { file: fileName.replace(/\.pdf$/i, ''), va: '', ward: '', union: '', upazila: '', district: '', gender: '' };
  for (let p = 1; p <= doc.numPages; p++) {
    const pg = await doc.getPage(p), tc = await pg.getTextContent(), d = pageData(tc.items); pg.cleanup();
    if (p <= 3) head.push(...d.lines.slice(0, 16));
    if (!m.va) d.lines.forEach(l => {
      const v = l.match(/ভোটার এলাকার নাম:\s*(.+?)\s*$/), c = l.match(/ভোটার এলাকার কোড:\s*([০-৯]+)/);
      if (v) m.va = v[1].trim() + (c ? ' (' + c[1] + ')' : '');
    });
    if (!m.upazila) d.lines.forEach(l => {
      const a = l.match(/জেলা:\s*(.+?)\s*উপজেলা:\s*(.+?)\s*ইউনিয়ন:\s*(.+?)\s*ডাকঘর:/);
      if (a && !m.upazila) { m.district = a[1].trim(); m.upazila = a[2].trim(); m.union = a[3].trim(); }
    });
    recs.push(...d.recs);
    if (p % 3 === 0) await new Promise(r => setTimeout(r));
  }
  try { await doc.destroy(); } catch (e) {}
  const txt = head.join('\n');
  const w = txt.match(/ওয়ার্ড নম্বর\s*\(ইউনিয়ন পরিষদের জন্য\)\s*:?\s*([০-৯]+)/); m.ward = w ? w[1] : '';
  const g = txt.match(/ভোটার তালিকা\s*-\s*\((পুরুষ|মহিলা)\)/);
  m.gender = g ? (g[1] === 'মহিলা' ? 'নারী' : 'পুরুষ') : (/female/i.test(fileName) ? 'নারী' : (/male/i.test(fileName) ? 'পুরুষ' : ''));
  return { m, recs };
}

// ---------- ছোট বার্তা (টোস্ট) ও কপি ----------
let toastT = 0;
function toast(msg) { const t = $('toast'); t.textContent = msg; t.classList.remove('hide'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.add('hide'), 2200); }
function copyText(text) {
  if (NATIVE && window.Android.copyText) { window.Android.copyText(text); return; }
  try { navigator.clipboard.writeText(text); } catch (e) {}
  toast('কপি হয়েছে: ' + text);
}
const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

// ---------- পেজ ও ট্যাব (সার্চ হোম, তারপর পরিসংখ্যান, তারপর ইমপোর্ট) ----------
let curTab = 'search', view = 'search';
const VIEWS = ['search', 'stats', 'import', 'bm', 'rel'], relStack = [];
function showView(v) { view = v; VIEWS.forEach(x => $('v-' + x).classList.toggle('hide', x !== v)); }
function markTab(t) { ['search', 'stats', 'import'].forEach(x => $('t-' + x).classList.toggle('on', x === t)); }
function tab(t) {
  curTab = t; closeCard(true); closeSheet(true); relStack.length = 0;
  showView(t); markTab(t); window.scrollTo(0, 0);
  if (t === 'stats') stats(); if (t === 'search') search(true); if (t === 'import') refreshInfo();
}
$('t-search').onclick = () => tab('search'); $('t-stats').onclick = () => tab('stats'); $('t-import').onclick = () => tab('import');

// ---------- স্মুথ অ্যানিমেশনসহ মডাল (কার্ড, অপশন-শিট) ----------
const raf = f => (window.requestAnimationFrame ? window.requestAnimationFrame(f) : setTimeout(f, 16));
const isOpen = el => el.classList.contains('show');
function showModal(el) { el.classList.remove('hide'); void el.offsetWidth; raf(() => el.classList.add('show')); }
function hideModal(el, instant) {
  el.classList.remove('show');
  if (instant) { el.classList.add('hide'); return; }
  setTimeout(() => { if (!isOpen(el)) el.classList.add('hide'); }, 260);
}

// ---------- ব্যাক বাটন: শিট/কার্ড বন্ধ → পরিবার/বুকমার্ক পেজ থেকে ফেরা → সার্চে ফেরা → অ্যাপ থেকে বের ----------
let exitArm = 0;
window.__back = function () {
  if (isOpen($('sheet'))) { closeSheet(); return true; }
  if (isOpen($('card'))) { closeCard(); return true; }
  if (view === 'rel') { relBack(); return true; }
  if (view === 'bm') { tab('search'); return true; }
  if (curTab !== 'search') { tab('search'); return true; }
  if (running) { if (Date.now() - exitArm < 3000) return false; exitArm = Date.now(); toast('ইমপোর্ট চলছে! আবার ব্যাক চাপলে অ্যাপ বন্ধ হবে'); return true; }
  return false;
};

// ---------- উপরে যাওয়ার তীর ----------
window.addEventListener('scroll', () => $('toTop').classList.toggle('hide', window.scrollY < 400), { passive: true });
$('toTop').onclick = () => window.scrollTo({ top: 0, behavior: 'smooth' });

// ---------- ডাবল ট্যাপে কার্ড (অ্যানিমেটেড) ----------
let cardR = null;
function closeCard(instant) { hideModal($('card'), instant); }
function openCard(r) {
  cardR = r;
  const a = age(r.dob_y, r.dob_m, r.dob_d);
  const rows = [['নাম', r.name], ['ভোটার নং', BDG(r.voter_no), 1], ['ক্রমিক নাম্বার', BDG(r.serial)], ['লিঙ্গ', r.gender], ['বয়স', a !== '' ? bn(a) + ' বছর' : ''],
    ['জন্ম তারিখ', BDG(r.dob)], ['পিতা', r.father], ['মাতা', r.mother], ['পেশা', r.job], ['ঠিকানা', r.addr], ['ভোটার এলাকা', r.voter_area],
    ['ইউনিয়ন', r.union_name], ['ওয়ার্ড নাম্বার', BDG(r.ward)], ['উপজেলা', r.upazila], ['জেলা', r.district], ['সোর্স (PDF)', r.file]];
  $('cardBody').innerHTML = '<div class="ch"><img src="logo.png" alt=""><b>ভোটার তথ্য কার্ড</b></div>' + rows.map(x =>
    '<div class="cr"><span class="cl">' + x[0] + '</span><span class="cv' + (x[2] ? ' vno" data-c="' + esc(x[1]) : '') + '">' + esc(x[1] || '—') + (x[2] ? ' 📋' : '') + '</span></div>').join('');
  const acts = document.createElement('div'); acts.className = 'row';
  const b1 = document.createElement('button'), b2 = document.createElement('button'), b3 = document.createElement('button');
  b1.id = 'cardBm'; b1.textContent = isBm(r) ? '★ বুকমার্ক করা আছে' : '☆ বুকমার্ক'; b1.onclick = () => { toggleBm(r); b1.textContent = isBm(r) ? '★ বুকমার্ক করা আছে' : '☆ বুকমার্ক'; };
  b2.id = 'cardFather'; b2.textContent = '👨 একই পিতা'; b2.disabled = !r.father; b2.onclick = () => openRel(r, 'father');
  b3.id = 'cardMother'; b3.textContent = '👩 একই মাতা'; b3.disabled = !r.mother; b3.onclick = () => openRel(r, 'mother');
  acts.append(b1, b2, b3); $('cardBody').appendChild(acts);
  showModal($('card')); $('card').scrollTop = 0;
}
$('cardClose').onclick = () => closeCard();
$('card').onclick = e => { if (e.target === $('card')) closeCard(); const v = e.target.closest('.vno'); if (v) copyText(v.dataset.c); };

// ---------- চেপে ধরলে অপশন (একই পিতা / একই মাতা) ----------
let sheetR = null;
function closeSheet(instant) { hideModal($('sheet'), instant); }
function openSheet(r) {
  sheetR = r; $('sheetTitle').textContent = r.name;
  $('optFather').textContent = '👨 একই পিতা' + (r.father ? ' (' + r.father + ')' : ''); $('optFather').disabled = !r.father;
  $('optMother').textContent = '👩 একই মাতা' + (r.mother ? ' (' + r.mother + ')' : ''); $('optMother').disabled = !r.mother;
  showModal($('sheet'));
}
$('optFather').onclick = () => { const r = sheetR; closeSheet(true); openRel(r, 'father'); };
$('optMother').onclick = () => { const r = sheetR; closeSheet(true); openRel(r, 'mother'); };
$('optCancel').onclick = () => closeSheet();
$('sheet').onclick = e => { if (e.target === $('sheet')) closeSheet(); };
function attachLong(e, r) {
  let t = 0, x0 = 0, y0 = 0;
  const clear = () => { clearTimeout(t); t = 0; };
  e.addEventListener('pointerdown', ev => {
    x0 = ev.clientX; y0 = ev.clientY; clear();
    t = setTimeout(() => { t = 0; e._lp = true; setTimeout(() => { e._lp = false; }, 800); openSheet(r); }, 520);
  });
  e.addEventListener('pointermove', ev => { if (t && (Math.abs(ev.clientX - x0) > 12 || Math.abs(ev.clientY - y0) > 12)) clear(); });
  ['pointerup', 'pointercancel', 'pointerleave'].forEach(n => e.addEventListener(n, clear));
  e.addEventListener('contextmenu', ev => ev.preventDefault());
}

// ---------- বুকমার্ক (ফোনে আলাদা জায়গায় থাকে, ডেটা মুছলেও থেকে যায়) ----------
let BM = [];
try { BM = JSON.parse(localStorage.getItem('bm') || '[]'); } catch (e) { BM = []; }
const BMF = ['serial', 'voter_no', 'name', 'father', 'mother', 'job', 'dob', 'addr', 'dob_y', 'dob_m', 'dob_d', 'voter_area', 'ward', 'union_name', 'upazila', 'district', 'gender', 'file'];
const bmKey = r => r.voter_no || ('#' + r.file + '/' + r.serial);
const isBm = r => BM.some(b => bmKey(b) === bmKey(r));
function saveBm() { try { localStorage.setItem('bm', JSON.stringify(BM)); } catch (e) { toast('বুকমার্ক সেভ করা যায়নি'); } $('bmCount').textContent = bn(BM.length); }
function toggleBm(r) {
  const k = bmKey(r), i = BM.findIndex(b => bmKey(b) === k);
  if (i >= 0) { BM.splice(i, 1); toast('বুকমার্ক থেকে সরানো হয়েছে'); }
  else { const s = {}; BMF.forEach(f => { s[f] = r[f] == null ? '' : r[f]; }); s.t = Date.now(); BM.unshift(s); toast('⭐ বুকমার্ক করা হয়েছে'); }
  saveBm();
  document.querySelectorAll('.star').forEach(el => { if (el.dataset.k === k) el.textContent = i >= 0 ? '☆' : '★'; });
  if (view === 'bm') renderBm();
}
function openBm() {
  closeCard(true); closeSheet(true); relStack.length = 0; showView('bm'); markTab(''); window.scrollTo(0, 0); renderBm();
}
function renderBm() {
  const f = nz($('bmFilter').value), L = $('bmList'); L.innerHTML = '';
  const list = BM.filter(b => !f || nz([b.name, b.father, b.mother, b.addr, b.voter_no, b.job].join(' ')).includes(f));
  $('bmHead').textContent = '⭐ বুকমার্ক: ' + bn(BM.length) + ' জন' + (f ? ' (খুঁজে পাওয়া: ' + bn(list.length) + ' জন)' : '');
  if (!BM.length) { L.innerHTML = '<div class="card st">এখনও কোনো বুকমার্ক নেই। যেকোনো ভোটারের কার্ডের ☆ চাপলে এখানে জমা হবে।</div>'; }
  list.forEach(b => L.appendChild(renderRow(b)));
}
$('bmBtn').onclick = openBm; $('bmFilter').oninput = renderBm; $('bmBack').onclick = () => tab('search');
let bmArm = 0;
$('bmClear').onclick = () => {
  const b = $('bmClear');
  if (!bmArm) { bmArm = setTimeout(() => { bmArm = 0; b.textContent = '🗑 সব বুকমার্ক মুছুন'; }, 4000); b.textContent = '⚠ নিশ্চিত? আবার চাপুন'; return; }
  clearTimeout(bmArm); bmArm = 0; b.textContent = '🗑 সব বুকমার্ক মুছুন'; BM = []; saveBm(); renderBm();
};

// ---------- একই পিতা / একই মাতা পেজ ----------
let relReturn = null, relSeq = 0;
const strictOn = () => localStorage.getItem('strict') !== '0';          // ডিফল্ট: স্ট্রিক্ট চালু
const likeEsc = s => s.replace(/[\\%_]/g, '\\$&');
function openRel(r, kind) {
  if (!relStack.length) relReturn = { view, tab: curTab, y: window.scrollY };
  relStack.push({ src: r, kind, off: 0 }); closeCard(true); closeSheet(true); showRelPage();
}
function relBack() {
  relStack.pop();
  if (relStack.length) { showRelPage(); return; }
  const rr = relReturn || { view: 'search', tab: 'search', y: 0 }; relReturn = null;
  showView(rr.view); markTab(rr.view === 'bm' ? '' : rr.tab); if (rr.view === 'bm') renderBm();
  window.scrollTo(0, rr.y || 0);
}
$('relBack').onclick = () => relBack();
$('strict').checked = strictOn();
$('strict').onchange = () => { localStorage.setItem('strict', $('strict').checked ? '1' : '0'); strictUi(); if (relStack.length) loadRel(true); };
function strictUi() {
  $('strictLbl').textContent = $('strict').checked ? 'স্ট্রিক্ট মোড: চালু' : 'স্ট্রিক্ট মোড: বন্ধ';
  $('strictHelp').textContent = $('strict').checked ? 'শুধু হুবহু একই নাম মিললে দেখাবে।' : 'নামের অংশ বা আংশিক মিললেও দেখাবে (বেশি ফলাফল আসতে পারে)।';
}
function showRelPage() {
  const cur = relStack[relStack.length - 1]; showView('rel'); markTab(''); window.scrollTo(0, 0);
  const label = cur.kind === 'father' ? 'পিতা' : 'মাতা', val = cur.kind === 'father' ? cur.src.father : cur.src.mother;
  $('relTitle').textContent = 'একই ' + label + ': ' + (val || '—'); strictUi();
  $('relPin').innerHTML = ''; $('relPin').appendChild(renderRow(cur.src, { pin: true, hl: cur.kind }));
  loadRel(true);
}
async function loadRel(reset) {
  const cur = relStack[relStack.length - 1]; if (!cur) return; const my = ++relSeq;
  if (reset) { cur.off = 0; $('relList').innerHTML = ''; $('relCount').textContent = 'খোঁজা হচ্ছে…'; }
  const col = cur.kind === 'father' ? 'father_n' : 'mother_n', src = cur.src;
  const val = (cur.kind === 'father' ? (src.fn || nz(src.father)) : (src.mn || nz(src.mother))) || '';
  if (!val) { $('relCount').textContent = 'নাম লেখা নেই'; $('relMore').classList.add('hide'); return; }
  let w, a;
  if (strictOn()) { w = 'v.' + col + '=?'; a = [val]; }
  else {
    const toks = val.split(/\s+/).filter(t => t.length >= 2);
    const all = toks.map(() => 'v.' + col + " LIKE ? ESCAPE '\\'").join(' AND ');
    w = '((' + (all ? all : '0') + ') OR (length(v.' + col + ')>=5 AND instr(?, v.' + col + ')>0))';
    a = toks.map(t => '%' + likeEsc(t) + '%'); a.push(val);
  }
  if (src.voter_no) { w += " AND COALESCE(v.vno,'')<>?"; a.push(src.voter_no); }
  const order = ' ORDER BY (v.dob_y IS NULL), v.dob_y, v.dob_m, v.dob_d, v.id';      // বড় থেকে ছোট
  let rows, total = null;
  try {
    rows = await q('SELECT ' + SHOW + FROM + ' WHERE ' + w + order + ' LIMIT 100 OFFSET ' + (cur.off | 0), a);
    if (reset) total = (await q('SELECT COUNT(*) c FROM voters v WHERE ' + w, a))[0].c;
  } catch (e) { $('relCount').textContent = 'সমস্যা: ' + e.message; return; }
  if (my !== relSeq) return;
  const L = $('relList'); rows.forEach(r => L.appendChild(renderRow(r, { hl: cur.kind })));
  cur.off += rows.length; $('relMore').classList.toggle('hide', rows.length < 100);
  if (reset) $('relCount').textContent = total ? 'মিলেছে: ' + bn(total) + ' জন · বয়স অনুযায়ী (বড় থেকে ছোট)' : 'আর কেউ মেলেনি' + (strictOn() ? ' (স্ট্রিক্ট মোড বন্ধ করলে আংশিক মিলও দেখা যাবে)' : '');
}
$('relMore').onclick = () => loadRel(false);

// ---------- সংরক্ষিত ডেটার তথ্য ----------
async function refreshInfo() {
  const a = { c: (await q('SELECT COUNT(*) c FROM voters'))[0].c, f: (await q('SELECT COUNT(*) f FROM pdfs'))[0].f };
  const sz = (await rpc('dbsize')).bytes;
  $('info').textContent = bn(a.c) + ' জন ভোটার, ' + bn(a.f) + 'টি PDF';
  $('dbinfo').textContent = 'ডেটাবেসে ' + bn(a.c) + ' জন ভোটার, ' + bn(a.f) + 'টি PDF থেকে। ফোনের স্টোরেজে জায়গা নিচ্ছে প্রায় ' + bn(Math.round(sz / 1048576)) + ' MB।';
  try { const p = await rpc('dbpath'); $('dbpath').textContent = p.dir; $('dbfile').textContent = 'ফাইল: ' + p.file.split('/').pop(); } catch (e) {}
  return a;
}
$('dbpath').onclick = () => { if (NATIVE && window.Android.openFolder) window.Android.openFolder(); };

// ---------- ইমপোর্ট ----------
let FILES = [], running = false, stopFlag = false;
$('pick').onclick = () => { if (!NATIVE) { $('found').textContent = 'এটা শুধু অ্যান্ড্রয়েড অ্যাপে চলে।'; return; } $('found').textContent = 'ফোল্ডার খোঁজা হচ্ছে…'; window.Android.pickFolder(); };
window.__folder = async json => {
  const j = JSON.parse(json); FILES = j.files || [];
  const have = new Set((await q('SELECT file FROM pdfs')).map(x => x.file));
  FILES.forEach(f => f.done = have.has(f.name.replace(/\.pdf$/i, '')));
  const nw = FILES.filter(f => !f.done).length;
  $('found').textContent = bn(FILES.length) + 'টি PDF পাওয়া গেছে। আগেই ইমপোর্ট করা: ' + bn(FILES.length - nw) + 'টি। নতুন: ' + bn(nw) + 'টি।';
  $('runCard').style.display = FILES.length ? '' : 'none'; $('prog').textContent = ''; $('errs').textContent = ''; $('barI').style.width = '0';
};
const fmt = s => { s = Math.round(s); const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60); return (h ? bn(h) + ' ঘণ্টা ' : '') + bn(m) + ' মিনিট'; };
$('stop').onclick = () => { stopFlag = true; $('stop').disabled = true; $('cur').textContent = 'থামানো হচ্ছে…'; };
$('start').onclick = async () => {
  if (running) return; const todo = FILES.filter(f => !f.done); if (!todo.length) { $('prog').textContent = 'নতুন কোনো PDF নেই।'; return; }
  running = true; stopFlag = false; $('start').disabled = true; $('stop').disabled = false; $('pick').disabled = true; $('clear').disabled = true;
  window.Android.keepAwake(true);
  const t0 = Date.now(); let n = 0, recTotal = 0; const errs = [];
  for (let i = 0; i < todo.length && !stopFlag; i++) {
    const f = todo[i]; $('cur').textContent = f.name;
    try {
      const { m, recs } = await parsePdf('/pdf/' + f.i, f.name);
      if (!recs.length) throw new Error('কোনো ভোটার পাওয়া যায়নি');
      await rpc('insert', { sql: PDF_SQL, rows: [pdfRow(m)] });
      const fid = (await q('SELECT fid FROM pdfs WHERE file=?', [m.file]))[0].fid;
      scanUnknown(recs, m.file); renderUnk();
      const rows = recs.map(r => toRow(r, fid));
      for (let k = 0; k < rows.length; k += 2000) await rpc('insert', { sql: VOTER_SQL, rows: rows.slice(k, k + 2000) });
      recTotal += recs.length; f.done = true;
    } catch (e) { errs.push(f.name + ': ' + e.message); }
    n++;
    const sec = (Date.now() - t0) / 1000, left = (todo.length - n) * sec / n;
    $('barI').style.width = (n / todo.length * 100) + '%';
    $('prog').textContent = bn(n) + '/' + bn(todo.length) + ' PDF, ' + bn(recTotal) + ' জন যোগ হয়েছে। বাকি সময় আনুমানিক ' + fmt(left);
    $('errs').textContent = errs.length ? bn(errs.length) + 'টি PDF-এ সমস্যা: ' + errs.slice(0, 5).join(' | ') : '';
  }
  window.Android.keepAwake(false); running = false;
  $('cur').textContent = stopFlag ? 'থামানো হয়েছে। আবার ফোল্ডার বেছে শুরু করলে বাকিগুলো থেকে চলবে।' : 'সম্পন্ন ✓';
  $('start').disabled = false; $('stop').disabled = true; $('pick').disabled = false; $('clear').disabled = false;
  await refreshInfo(); LOADED_STATS = false;
};

// ---------- অজানা অক্ষর (নতুন যুক্তাক্ষর) ধরা ও অ্যাপের ভেতর থেকেই ঠিক করা ----------
const UNK_RE = /[^\u0980-\u09FF\u0020-\u007E\u200C\u200D\u0964\u25A1]/;
const unk = {};
function scanUnknown(recs, file) {
  for (const r of recs) for (const f of [r.name, r.father, r.mother, r.job, r.addr]) {
    if (!f || !UNK_RE.test(f)) continue;
    for (const ch of f) if (UNK_RE.test(ch)) {
      const c = ch.charCodeAt(0), u = unk[c] || (unk[c] = { ch, ex: f, n: 0, files: new Set() });
      u.n++; u.files.add(file);
    }
  }
}
function renderUnk() {
  const ks = Object.keys(unk), L = $('unkList'); L.innerHTML = '';
  $('unkCard').style.display = ks.length ? '' : 'none'; if (!ks.length) return;
  ks.forEach(k => {
    const u = unk[k], e = document.createElement('div'); e.className = 'u';
    e.innerHTML = '<div><b>' + esc(u.ch) + '</b> (কোড ' + k + ') · ' + bn(u.n) + ' বার · উদাহরণ: ' + esc(u.ex.slice(0, 40)) + '</div>' +
      '<div class="row"><input placeholder="সঠিক যুক্তাক্ষর লিখুন, যেমন শ্ত"><button class="p">সেভ</button></div><div class="st"></div>';
    const inp = e.querySelector('input'), msg = e.querySelector('.st');
    if (CUSTOM[k]) { inp.value = CUSTOM[k]; msg.textContent = 'সেভ করা আছে: ' + CUSTOM[k]; }
    e.querySelector('button').onclick = () => {
      const v = inp.value.trim(); if (!v) { msg.textContent = 'সঠিক যুক্তাক্ষর লিখুন'; return; }
      CUSTOM[k] = v; M[k] = v; localStorage.setItem('gmap', JSON.stringify(CUSTOM));
      msg.textContent = '✓ সেভ হয়েছে। এই অক্ষর এখন থেকে "' + v + '" হবে (নতুন ইমপোর্ট থেকে)। আগে ইমপোর্ট করা PDF ঠিক করতে নিচের "প্রভাবিত PDF মুছুন" চেপে আবার ইমপোর্ট করুন।';
    };
    L.appendChild(e);
  });
}
$('unkReport').onclick = () => copyText(Object.keys(unk).map(k => unk[k].ch + '=' + k + ' | ' + unk[k].ex.slice(0, 40)).join('\n'));
$('unkDel').onclick = async () => {
  const b = $('unkDel'); const files = new Set(); Object.keys(unk).forEach(k => unk[k].files.forEach(f => files.add(f)));
  if (!files.size) return;
  if (!b.dataset.c) { b.dataset.c = 1; b.textContent = '⚠ ' + bn(files.size) + 'টি PDF মুছবেন? আবার চাপুন'; setTimeout(() => { b.dataset.c = ''; b.textContent = 'প্রভাবিত PDF মুছুন'; }, 4000); return; }
  b.dataset.c = ''; b.textContent = 'প্রভাবিত PDF মুছুন';
  for (const f of files) {
    await rpc('exec', { sql: 'DELETE FROM voters WHERE fid IN (SELECT fid FROM pdfs WHERE file=?)', args: [f] });
    await rpc('exec', { sql: 'DELETE FROM pdfs WHERE file=?', args: [f] });
  }
  Object.keys(unk).forEach(k => delete unk[k]); renderUnk(); FILES.forEach(f => { if (files.has(f.name.replace(/\.pdf$/i, ''))) f.done = false; });
  $('found').textContent = 'মুছে ফেলা হয়েছে। এখন আবার ফোল্ডার বেছে ইমপোর্ট চালান, শুধু এই PDF-গুলোই নতুন করে ঢুকবে।'; await refreshInfo();
};

// ---------- ডেটা মুছুন (দুইবার নিশ্চিত) ----------
let clearArm = 0;
$('clear').onclick = async () => {
  const b = $('clear');
  if (!clearArm) {
    clearArm = setTimeout(() => { clearArm = 0; b.textContent = '🗑 ডেটা মুছুন'; $('clearMsg').textContent = ''; }, 5000);
    b.textContent = '⚠ নিশ্চিত? আবার চাপুন'; $('clearMsg').textContent = 'আবার চাপলে সব ইমপোর্ট করা ডেটা মুছে ফোনের জায়গা খালি হবে। ৫ সেকেন্ডের মধ্যে চাপুন।'; return;
  }
  clearTimeout(clearArm); clearArm = 0; b.textContent = '🗑 ডেটা মুছুন';
  await rpc('clear', { statements: SCHEMA });
  FILES.forEach(f => f.done = false); $('clearMsg').textContent = 'সব ডেটা মুছে গেছে, স্টোরেজ খালি হয়েছে ✓';
  $('list').innerHTML = ''; $('count').textContent = ''; Object.keys(unk).forEach(k => delete unk[k]); renderUnk(); await refreshInfo(); LOADED_STATS = false;
};

// ---------- সার্চ ----------
const F = { job: '' };
function dobSql(s) {
  s = nz(s).replace(/[-–—.\s]+/g, '/'); const p = s.split('/').filter(Boolean);
  if (!p.length || !p.every(x => /^\d+$/.test(x))) return null; const n = p.map(Number);
  if (p.length >= 3) return p[2].length >= 4 ? ['dob_d=? AND dob_m=? AND dob_y=?', [n[0], n[1], n[2]]] : ['dob_d=? AND dob_m=? AND CAST(dob_y AS TEXT) LIKE ?', [n[0], n[1], p[2] + '%']];
  if (p.length === 2) return p[1].length >= 3 ? ['dob_m=? AND CAST(dob_y AS TEXT) LIKE ?', [n[0], p[1] + '%']] : ['dob_d=? AND dob_m=?', [n[0], n[1]]];
  return p[0].length >= 3 ? ['CAST(dob_y AS TEXT) LIKE ?', [p[0] + '%']] : ['dob_d=?', [n[0]]];
}
function buildWhere() {
  const w = [], a = [], steps = [], pw = [], pa = [];
  const like = (col, val, lab) => {
    const t = nz(val).split(/\s+/).filter(Boolean); if (!t.length) return;
    t.forEach(x => { w.push(col + " LIKE ? ESCAPE '\\'"); a.push('%' + x.replace(/[\\%_]/g, '\\$&') + '%'); }); steps.push(lab);
  };
  const plike = (col, val, lab) => {
    const t = nz(val).split(/\s+/).filter(Boolean); if (!t.length) return;
    t.forEach(x => { pw.push(col + " LIKE ? ESCAPE '\\'"); pa.push('%' + x.replace(/[\\%_]/g, '\\$&') + '%'); }); steps.push(lab);
  };
  like('v.name_n', $('f-name').value, 'নাম'); like('v.father_n', $('f-father').value, 'বাবা'); like('v.mother_n', $('f-mother').value, 'মা');
  const d = dobSql($('f-dob').value); if (d) { w.push('(' + d[0].replace(/dob_/g, 'v.dob_') + ')'); a.push(...d[1]); steps.push('জন্ম তারিখ'); }
  like('v.addr_n', $('f-addr').value, 'ঠিকানা');
  plike('un_n', $('f-union').value, 'ইউনিয়ন'); plike('va_n', $('f-va').value, 'ভোটার এলাকা');
  const wd = nz($('f-ward').value).trim(); if (wd) { pw.push('ward_n=?'); pa.push(wd); steps.push('ওয়ার্ড'); }
  const g = $('f-gender').value; if (g) { pw.push('gender=?'); pa.push(g); steps.push(g); }
  if (pw.length) { w.push('v.fid IN (SELECT fid FROM pdfs WHERE ' + pw.join(' AND ') + ')'); a.push(...pa); }
  if (F.job) { w.push('v.job=?'); a.push(F.job); steps.push('পেশা'); }
  return { sql: w.length ? ' WHERE ' + w.join(' AND ') : '', args: a, steps };
}
function chips() {
  const c = $('chips'); c.innerHTML = '';
  if (F.job) { const s = document.createElement('span'); s.className = 'chip'; s.textContent = 'পেশা: ' + F.job + ' ✕'; s.onclick = () => { F.job = ''; search(true); }; c.appendChild(s); }
}
function age(y, m, d) { if (!y) return ''; const n = new Date(); let a = n.getFullYear() - y; if (n.getMonth() + 1 < m || (n.getMonth() + 1 === m && n.getDate() < d)) a--; return a; }
let seq = 0, off = 0, curW = null, timer = null;
const SHOW = 'v.id AS rid,v.father_n AS fn,v.mother_n AS mn,v.serial,v.vno AS voter_no,v.name,v.father,v.mother,v.job,v.dob,v.addr,v.dob_y,v.dob_m,v.dob_d,p.va AS voter_area,p.ward,p.union_name,p.upazila,p.district,p.gender,p.file';
const FROM = ' FROM voters v JOIN pdfs p ON p.fid=v.fid';
function shuffle(a) { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
async function randomRows() {                    // ফিল্টার ছাড়া: প্রতিবার ভিন্ন এলোমেলো ৫০ জন
  const m = (await q('SELECT MAX(id) m FROM voters'))[0].m || 0; if (!m) return [];
  const ids = new Set(), need = Math.min(m, 80);
  while (ids.size < need) ids.add(1 + Math.floor(Math.random() * m));
  return shuffle(await q('SELECT ' + SHOW + FROM + ' WHERE v.id IN (' + [...ids].join(',') + ') LIMIT 50'));
}
let lastTap = { el: null, t: 0 };
function renderRow(r, o) {
  o = o || {};
  const e = document.createElement('div'); e.className = 'v' + (o.pin ? ' pin' : '');
  const a = age(r.dob_y, r.dob_m, r.dob_d), vn = BDG(r.voter_no), k = bmKey(r);
  e.innerHTML = (o.pin ? '<div class="pl">📌 নির্বাচিত ব্যক্তি</div>' : '') +
    '<span class="star" data-k="' + esc(k) + '">' + (isBm(r) ? '★' : '☆') + '</span>' +
    '<b>' + esc(r.name) + '</b> <span class="t vno" data-c="' + esc(vn) + '">ভোটার নং: ' + esc(vn) + ' 📋</span>' +
    '<div class="' + (o.hl === 'father' ? 'm' : '') + '">পিতা: ' + esc(r.father) + '</div><div class="' + (o.hl === 'mother' ? 'm' : '') + '">মাতা: ' + esc(r.mother) + '</div>' +
    '<div>জন্ম: ' + esc(BDG(r.dob)) + ' | পেশা: ' + esc(r.job) + '</div><div>ঠিকানা: ' + esc(r.addr) + '</div>' +
    '<div class="l">ভোটার এলাকা: ' + esc(r.voter_area) + ' | ইউনিয়ন: ' + esc(r.union_name) + ' | ওয়ার্ড: ' + esc(r.ward) + '</div>' +
    '<div class="l">ক্রমিক: ' + esc(BDG(r.serial)) + ' | লিঙ্গ: ' + esc(r.gender) + (a !== '' ? ' | বয়স: ' + bn(a) + ' বছর' : '') + '</div>' +
    '<div class="l">সোর্স: ' + esc(r.file) + '</div>';
  attachLong(e, r);
  e.onclick = ev => {
    if (e._lp) { e._lp = false; return; }                         // চেপে ধরার পর যে ক্লিক আসে সেটা বাদ
    if (ev.target.closest('.star')) { toggleBm(r); return; }
    const v = ev.target.closest('.vno'); if (v) { copyText(v.dataset.c); return; }
    const n = Date.now();
    if (lastTap.el === e && n - lastTap.t < 450) { lastTap = { el: null, t: 0 }; openCard(r); } else lastTap = { el: e, t: n };
  };
  return e;
}
async function search(reset) {
  const my = ++seq; if (reset) { off = 0; $('list').innerHTML = ''; }
  const w = curW = buildWhere(); chips(); const rand = !w.sql;
  $('steps').textContent = w.steps.length ? 'ফিল্টার: ' + w.steps.join(' + ') : 'ফিল্টার না দিলে প্রতিবার এলোমেলো ৫০ জন দেখায়';
  let rows;
  try { rows = rand ? await randomRows() : await q('SELECT ' + SHOW + FROM + w.sql + ' LIMIT 50 OFFSET ' + (off | 0), w.args); } catch (e) { $('count').textContent = 'সমস্যা: ' + e.message; return; }
  if (my !== seq) return;
  const L = $('list'); rows.forEach(r => L.appendChild(renderRow(r)));
  off += rows.length; $('more').classList.toggle('hide', rand ? !rows.length : rows.length < 50);
  if (reset) {
    $('count').textContent = 'গোনা হচ্ছে…';
    const c = (await q('SELECT COUNT(*) c FROM voters v' + w.sql, w.args))[0].c;
    if (my === seq) $('count').textContent = !c && rand ? 'ডেটাবেস খালি, "ইমপোর্ট" ট্যাব থেকে PDF ইমপোর্ট করুন' : 'মোট ' + bn(c) + ' জন' + (rand ? ' (এলোমেলো ৫০ জন দেখানো হচ্ছে)' : '');
  }
}
['f-name', 'f-father', 'f-mother', 'f-dob', 'f-addr', 'f-union', 'f-va', 'f-ward'].forEach(id => $(id).oninput = () => { clearTimeout(timer); timer = setTimeout(() => search(true), 700); });
$('f-gender').onchange = () => search(true);
$('go').onclick = () => { clearTimeout(timer); search(true); };
$('more').onclick = () => search(false);
$('reset').onclick = () => { ['f-name', 'f-father', 'f-mother', 'f-dob', 'f-addr', 'f-union', 'f-va', 'f-ward'].forEach(id => $(id).value = ''); $('f-gender').value = ''; F.job = ''; search(true); };

// ---------- পরিসংখ্যান ----------
let statsMode = 'all', LOADED_STATS = false;
$('s-all').onclick = () => { statsMode = 'all'; $('s-all').classList.add('p'); $('s-cur').classList.remove('p'); stats(); };
$('s-cur').onclick = () => { statsMode = 'cur'; $('s-cur').classList.add('p'); $('s-all').classList.remove('p'); stats(); };
async function stats() {
  const w = statsMode === 'cur' ? buildWhere() : { sql: '', args: [] };
  const g = await q('SELECT p.gender gender, COUNT(*) c' + FROM + w.sql + ' GROUP BY p.gender', w.args);
  const cnt = k => (g.find(x => x.gender === k) || { c: 0 }).c, tot = g.reduce((a, x) => a + x.c, 0), pc = c => tot ? ' (' + bn((c / tot * 100).toFixed(1)) + '%)' : '';
  $('s-gender').innerHTML = '<div class="g">মোট<b>' + bn(tot) + '</b></div><div class="g">পুরুষ<b>' + bn(cnt('পুরুষ')) + '</b><span class="st">' + pc(cnt('পুরুষ')) + '</span></div><div class="g">নারী<b>' + bn(cnt('নারী')) + '</b><span class="st">' + pc(cnt('নারী')) + '</span></div>';
  const jobs = await q('SELECT v.job job, COUNT(*) c FROM voters v' + w.sql + ' GROUP BY v.job ORDER BY c DESC LIMIT 300', w.args);
  const mx = jobs.length ? jobs[0].c : 1, J = $('s-jobs'); J.innerHTML = '';
  jobs.forEach(j => {
    const e = document.createElement('div'); e.className = 'jr';
    const name = j.job || '(পেশা লেখা নেই)';
    e.innerHTML = '<div class="n"><span></span><b>' + bn(j.c) + (tot ? ' · ' + bn((j.c / tot * 100).toFixed(1)) + '%' : '') + '</b></div><div class="jb"><i style="width:' + (j.c / mx * 100) + '%"></i></div>';
    e.querySelector('span').textContent = name;
    e.onclick = () => { F.job = j.job || ''; if (F.job) { tab('search'); } };
    J.appendChild(e);
  });
}

// ---------- শুরু ----------
(async () => {
  if (!NATIVE) { $('info').textContent = 'এটা শুধু অ্যান্ড্রয়েড অ্যাপে চলে'; return; }
  $('bmCount').textContent = bn(BM.length); await rpc('init', { statements: SCHEMA }); await refreshInfo(); renderUnk(); strictUi(); tab('search');
})();
