// GID -> Unicode for the EC "Bangla" font (glyphs without ToUnicode)
const M={121:'ক্',123:'গ',138:'দ্',140:'ন্',142:'ফ্',145:'ম্',152:'হ্',162:'ন্',194:'য়',203:'্য',206:'\uE000',207:'ে',208:'ৈ',
209:'ক্ক',212:'ক্স',215:'ক্ত',216:'ক্র',217:'ক্ষ',224:'গ্ধ',229:'গ্র',232:'ঙ্ক',234:'ঙ্গ',238:'চ্চ',245:'জ্জ',250:'জ্ব',251:'ঞ্চ',253:'ঞ্জ',
255:'ট্ট',256:'ট্র',259:'ড্র',263:'ণ্ড',272:'ত্ন',275:'ত্ত',276:'ত্র',279:'দ্দ',281:'দ্র',283:'দ্ব',284:'দ্ধ',290:'ন্ত',292:'ন্দ',293:'ন্ম',
294:'ন্ধ',295:'ন্দ্র',296:'ন্ন',297:'ন্স',303:'ন্য',304:'প্ত',305:'প্ল',306:'প্প',307:'প্ন',308:'প্র',311:'ফ্র',314:'ব্দ',316:'ব্ব',317:'ব্র',
322:'ম্প',324:'ম্ব',326:'ম্র',327:'ম্ম',331:'ল্ট',332:'ল্ল',336:'ল্প',340:'শ্চ',344:'শ্র',345:'শ্য',347:'শ্ব',349:'ষ্ণ',350:'ষ্ট',353:'ষ্প',
354:'ষ্ট্র',358:'স্ক',360:'স্ট',361:'স্ত',362:'স্থ',363:'স্ন',364:'স্প',366:'স্ব',367:'স্ম',368:'স্র',369:'স্ত্র',380:'হ্য',381:'গু',383:'নু',
384:'সু',385:'রু',386:'রূ',387:'দু',388:'শু',389:'হৃ',390:'হু',398:'স্তু',399:'ন্দু',419:'কু',420:'কৃ',128:'জ্',168:'স',204:'্র',205:'',218:'ক্ষ্ম',248:'জ্ঞ',249:'জ্জ্ব',271:'ত্ম',282:'দ্ম',318:'ব্ল',335:'ল্ড',348:'ষ্ক',382:'ন্ত',414:'মদ'};
const REPH='\uE000',HAL='্',PRE='িেৈ';
const isB=c=>!!c&&((c>='\u0980'&&c<='\u09FF')||c.charCodeAt(0)>=128);
const isC=t=>!!t&&/[\u0995-\u09B9\u09CE\u09DC-\u09DF]/.test(t[0]);
function toks(s){ // pdf.js string (unmapped GIDs appear as char codes) -> glyph tokens
  const a=[...s],o=[];
  for(let i=0;i<a.length;i++){
    const c=a[i],k=c.charCodeAt(0);
    if((k===121||k===123)&&!(isB(a[i-1])||isB(a[i+1]))){o.push(c);continue}
    if(k in M&&k>=121){if(M[k])o.push(M[k])}else if(k===0)o.push('□');else if(c==='◌'){
      if(a[i+1]===HAL){const x=a[i+2],y=a[i+3];if(x&&x===y&&isC(x)){o.push(x,HAL);i+=2}else i++}
    }else o.push(c);
  }
  for(let j=0;j+1<o.length;j++)if(o[j].length===2&&o[j].endsWith(HAL)&&o[j+1]===o[j])o[j+1]=o[j+1][0];
  for(let j=0;j+1<o.length;j++)if(o[j]==='ঁ'&&o[j+1].length===1&&'ািীুূৃৗ'.includes(o[j+1])){o[j]=o[j+1];o[j+1]='ঁ'}
  return o;
}
function fix(s){ // visual order -> logical Unicode order
  const t=toks(s),o=[];let i=0;const n=t.length;
  while(i<n){
    let pre='';
    while(i<n&&t[i].length===1&&PRE.includes(t[i])){pre+=t[i];i++}
    if(i<n&&isC(t[i])){
      let cl=t[i++];
      while(i<n&&((cl.endsWith(HAL)&&isC(t[i]))||t[i][0]===HAL))cl+=t[i++];
      let bv='';
      while(i<n&&t[i].length===1&&'ুূৃ'.includes(t[i]))bv+=t[i++];
      let r='';
      if(t[i]===REPH){r='র্';i++}
      let v='';
      if(pre.includes('ে')&&(t[i]==='া'||t[i]==='ৗ')){v=t[i]==='া'?'ো':'ৌ';i++;pre=pre.replace('ে','')}
      o.push(r+cl+bv+v+pre);
    }else{o.push(pre);if(i<n){o.push(t[i]===REPH?'র্':t[i]);i++}}
  }
  return o.join('').normalize('NFC');
}
const SER=/^[০-৯]{1,5}\./;
function pageData(items){ // pdf.js text items -> {lines, recs}
  const it=items.filter(i=>Math.abs(i.transform[1])<0.01&&Math.abs(i.transform[2])<0.01).map(i=>({s:fix(i.str),x:i.transform[4],y:i.transform[5]})).filter(i=>i.s.length);
  const isFoot=i=>/^[০-৯]+$/.test(i.s.trim())&&i.y<90;
  const body=it.filter(i=>!isFoot(i));
  const cols=[...new Set(body.filter(i=>/^[০-৯]{1,5}\.\s*নাম:/.test(i.s.trim())).map(i=>Math.round(i.x)))].sort((a,b)=>a-b);
  const col=i=>{let c=0;cols.forEach((x,k)=>{if(i.x>=x-3)c=k});return c};
  const mk=a=>{a=a.slice().sort((p,q)=>q.y-p.y||p.x-q.x);const L=[];let cy=null,cur=null;
    for(const i of a){if(cy===null||Math.abs(cy-i.y)>3){cur=[];L.push(cur);cy=i.y}cur.push(i)}
    return L.map(l=>l.sort((p,q)=>p.x-q.x).map(i=>i.s).join('').replace(/ +/g,' ').trim()).filter(Boolean)};
  if(!cols.length)return{lines:mk(body),recs:[]};
  const lines=[],recs=[];
  for(let c=0;c<cols.length;c++){
    const ls=mk(body.filter(i=>col(i)===c));let cur=null;
    for(const l of ls){
      if(SER.test(l)){cur=[l];recs.push(cur)}else if(cur)cur.push(l);else lines.push(l);
    }
  }
  const head=mk(body.filter(i=>!cols.length||i.y>Math.max(...body.filter(j=>SER.test(j.s.trim())).map(j=>j.y))+3));
  return{lines:head.concat(recs.map(r=>r.join('\n'))),recs:recs.map(parseRec).filter(Boolean)};
}
function parseRec(r){
  const t=r.join?r.join('\n'):r;if(!/নাম:/.test(t))return null;const g=(a)=>{const m=t.match(a);return m?m[1].replace(/\s*\n\s*/g,' ').trim():''};
  return{serial:g(/^([০-৯]{1,5})\./),name:g(/নাম:\s*([\s\S]*?)\s*(?=ভোটার নং:|$)/)||g(/^[০-৯]{1,5}\.\s*([\s\S]*)$/),no:g(/ভোটার নং:\s*([০-৯0-9]+)/),
    father:g(/পিতা:\s*([\s\S]*?)\s*(?=মাতা:|পেশা:|ঠিকানা:|$)/),mother:g(/মাতা:\s*([\s\S]*?)\s*(?=পেশা:|ঠিকানা:|$)/),
    job:g(/পেশা:\s*([\s\S]*?)\s*,?\s*(?=জন্ম তারিখ:|ঠিকানা:|$)/),dob:g(/জন্ম তারিখ:\s*([০-৯\/]+)/),addr:g(/ঠিকানা:\s*([\s\S]*)$/)};
}
if(typeof module!=='undefined')module.exports={fix,toks,pageData,parseRec};
